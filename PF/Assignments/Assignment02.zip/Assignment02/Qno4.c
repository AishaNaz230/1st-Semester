#include<stdio.h>

int get_valid_days();
float calc_daily_sales(int day_number);
int highest_sales_day(float daily_sales[],int num_of_days);
void display_barchart(float daily_sales[],int num_of_days);

int main(){
    float daily_sales[7];
    int num_of_days;
    float total_festival_sales=0;
    int highest_day;

    num_of_days=get_valid_days();
    for(int i=0;i<num_of_days;i++){
        daily_sales[i]=calc_daily_sales(i+1);
        total_festival_sales=total_festival_sales+daily_sales[i];
    }
    highest_day=highest_sales_day(daily_sales,num_of_days);
    printf("Total festival sales: %.2f\n",total_festival_sales);
    printf("Day with highest sales: %d\n",highest_day);
    printf("Highest daily sales: %.2f\n",daily_sales[highest_day-1]);

    display_barchart(daily_sales,num_of_days);

    return 0;
}
int get_valid_days(){
    int days;
    printf("Enter days: ");
    scanf("%d",&days);
    while (days<1 || days>7)
    {
        printf("Invalid! Enter number of days(1-7)");
        scanf("%d",&days);
    }
    return days;
}
float calc_daily_sales(int day_number){
    int num_orders;
    float amount;
    float total_sales=0;
    float highest_order=0;

    printf("Day %d-Number of orders: ",day_number);
    scanf("%d",&num_orders);

    printf("Order amounts: ");
    for(int i=0;i<num_orders;i++){
         scanf("%f",&amount);
    
      while(amount<=0){
        printf("Invalid amount! enter again: ");
        scanf("%f",&amount);
      }
       total_sales=total_sales+amount;
       if(amount>highest_order){
        highest_order=amount;
       
      }
    }
    float avg_order=total_sales/num_orders;

    printf("Total sales: %.2f\n",total_sales);
    printf("Average order: %.2f\n",avg_order);
    printf("Highest order: %.2f\n",highest_order);

    return total_sales;
}
int highest_sales_day(float daily_sales[],int num_of_days){
    int highest_index=0;
    float highest_sales=daily_sales[0];
    for(int i=0;i<num_of_days;i++){
        if(daily_sales[i]>highest_sales){
            highest_sales=daily_sales[i];
            highest_index=i;
        }
    }
    return highest_index+1;
}
void display_barchart(float daily_sales[],int num_of_days){
    for(int i=0;i<num_of_days;i++){
        int num_stars=(int)(daily_sales[i])/100;
        printf("Day %d: ",i+1);
        for(int j=0;j<num_stars;j++){
            printf("*");
        }
        printf("(Rs %.2f)\n",daily_sales[i]);
    }
}