
#include <stdio.h>

int main() {
    int i, j;
    int r, c;
    int k,count;
    int row1=0,row2=0;
    int found=0;
    int starting_row,starting_seat;

    printf("Enter rows: ");
    scanf("%d", &r);

    printf("Enter columns: ");
    scanf("%d", &c);

    int seat[r][c];
   
    for(i = 0;i < r;i++){
        for(j = 0;j < c;j++){
            printf("Enter number of seats(0 for available seats)(1 for booked seats): \n");
            scanf("%d", &seat[i][j]);
        }
        printf("\n");
    }
    printf("   ");
    for(j = 0;j < c;j++){
        printf("%d",j);
    }
    printf("\n");
    for(i = 0;i < r;i++){
        printf("R%d",i);
        for(j = 0;j < c;j++){
            if(seat[i][j]==0){
                printf(" _ ");
            }
            else{
                printf(" x ");
            }
        }
        printf("\n");
    }
    int totalFree=0;
    for(i=0;i<r;i++){
        int rowFree=0;
        for(j=0;j<c;j++){
            if(seat[i][j]==0){
                rowFree++;
            }
        }
        printf("Free Rows are %d\n",rowFree);
        totalFree=totalFree+rowFree;
    }
    printf("Total free seats :%d\n",totalFree);

    printf("Enter number of customers(k):");
    scanf("%d",&k);

    if(k<=0||k>c){
        printf("Invalid group size. it must be greater than zero and less than equal to %d\n",c);
        return 0;
    }
    int mid=r/2;
    for(int dis=0;dis<=r&&!found;dis++){
        row1=mid-dis;
        row2=mid+dis;
        if(row1>=0&&row1<r&&!found){
            count=0;
            for(j=0;j<c;j++){
                if(seat[row1][j]==0){
                    count++;
                    if(count==k){
                        found=1;
                        starting_row=row1;
                        starting_seat=j-k+1;
                        break;
                    }
                }
                else{
                    count=0;
                }
            }
        }
        if(row2>=0&&row2<r&&row2!=row1&&!found){
            count=0;
            for(j=0;j<c;j++){
                if(seat[row2][j]==0){
                    count++;
                    if(count==k){
                        found=1;
                        starting_row=row2;
                        starting_seat=j-k+1;
                        break;
                    }
                }
                else{
                    count=0;
                }
            }
        }
    }
    if(found==1){
        for(j=starting_seat;j<starting_seat+k;j++){
            seat[starting_row][j]=1;
        }
        printf("Group of %d seated in row %d ,seats %d to %d\n",k,starting_row,starting_seat,starting_seat+k-1);

         printf("   ");
    for(j = 0;j < c;j++){
        printf("%d ",j);
    }
    printf("\n");
    for(i = 0;i < r;i++){
        printf("R%d",i);
        for(j = 0;j < c;j++){
            if(seat[i][j]==0){
                printf(" _ ");
            }
            else{
                printf(" x ");
            }
        }
        printf("\n");
    }
    totalFree=0;
    for(i=0;i<r;i++){
        for(j=0;j<c;j++){
            if(seat[i][j]==0){
                totalFree++;
            }
        }
    }
    printf("Remaining seats are %d\n",totalFree);
    }
    else{
        printf("No suitable block of %d consecutive seats found . Booking failed.\n",k);
    }

}
