#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_BORROW   3
#define STUDENT      1
#define FACULTY      2
#define STUDENT_DAYS 14
#define FACULTY_DAYS 30
#define STUDENT_RATE 20
#define FACULTY_RATE 10
#define WAIVER_CODE  "LIB2026"

int readInt(void)
{
    int value, c;
    while (scanf("%d", &value)!= 1) {
        if (feof(stdin))
            exit(0);
        while ((c = getchar()) != '\n' && c != EOF)
            ;
        printf("Invalid input. Enter a number: ");
    }
    return value;
}

void displayMenu()
{
    printf("\n===== University Library Management System =====\n");
    printf("1. Member Registration\n");
    printf("2. Display Available Books\n");
    printf("3. Borrow a Book\n");
    printf("4. Return a Book\n");
    printf("5. Display Member Record\n");
    printf("6. Exit\n");
    printf("Enter your choice: ");
}

void registerMember(char name[], int *studentID, int *memberType)
{
    printf("Enter name: ");
    scanf(" %49[^\n]", name);

    printf("Enter student ID: ");
    *studentID = readInt();

    do {
        printf("Membership type (1 = Student, 2 = Faculty): ");
        *memberType = readInt();
        if (*memberType != STUDENT && *memberType != FACULTY)
            printf("Invalid membership type. Try again.\n");
    } while (*memberType != STUDENT && *memberType != FACULTY);

    printf("Registration successful.\n");
}

void displayBooks(int bookIDs[], char bookTitles[][50], int availableCopies[], int totalBooks)
{
    int i;
    printf("\n%-6s %-25s %s\n", "ID", "Title", "Copies");
    printf("------------------------------------------\n");
    for (i = 0; i < totalBooks; i++)
        printf("%-6d %-25s %d\n", bookIDs[i], bookTitles[i], availableCopies[i]);
}

void borrowBook(int bookIDs[], char bookTitles[][50], int availableCopies[], int totalBooks,
                int borrowedBookIDs[], int *borrowedCount, int memberType)
{
    int id, days, i, index = -1;
    int allowed = (memberType == STUDENT) ? STUDENT_DAYS : FACULTY_DAYS;

    if (*borrowedCount >= MAX_BORROW) {
        printf("Borrowing limit reached (maximum %d books).\n", MAX_BORROW);
        return;
    }

    printf("Enter book ID: ");
    id = readInt();

    for (i = 0; i < totalBooks; i++) {
        if (bookIDs[i] == id) {
            index = i;
            break;
        }
    }
    if (index == -1) {
        printf("Invalid book ID.\n");
        return;
    }
    if (availableCopies[index] == 0) {
        printf("Sorry, no copies of \"%s\" are available.\n", bookTitles[index]);
        return;
    }

    for (i = 0; i < *borrowedCount; i++) {
        if (borrowedBookIDs[i] == id) {
            printf("You have already borrowed this book.\n");
            return;
        }
    }

    printf("Enter number of days you intend to keep the book: ");
    days = readInt();
    if (days <= 0) {
        printf("Number of days must be positive.\n");
        return;
    }

    borrowedBookIDs[*borrowedCount] = id;
    (*borrowedCount)++;
    availableCopies[index]--;

    printf("You borrowed \"%s\".\n", bookTitles[index]);
    if (days > allowed)
        printf("Note: the permitted period is %d days; later returns incur a fine.\n", allowed);
}

float returnBook(int bookIDs[], int availableCopies[], int totalBooks, int borrowedBookIDs[],
                 int *borrowedCount, int memberType, float *totalFine)
{
    int id, days, i, bookIndex = -1, borrowedIndex = -1;
    int allowed = (memberType == STUDENT) ? STUDENT_DAYS : FACULTY_DAYS;
    int rate = (memberType == STUDENT) ? STUDENT_RATE : FACULTY_RATE;
    float fine = 0.0f, payable = 0.0f;
    char code[50];

    if (*borrowedCount == 0) {
        printf("You have no borrowed books to return.\n");
        return 0.0f;
    }

    printf("Enter book ID to return: ");
    id = readInt();

    for (i = 0; i < *borrowedCount; i++) {
        if (borrowedBookIDs[i] == id) {
            borrowedIndex = i;
            break;
        }
    }
    if (borrowedIndex == -1) {
        printf("You have not borrowed a book with ID %d.\n", id);
        return 0.0f;
    }

    printf("Enter actual number of days the book was kept: ");
    days = readInt();
    if (days <= 0) {
        printf("Number of days must be positive.\n");
        return 0.0f;
    }

    for (i = 0; i < totalBooks; i++) {
        if (bookIDs[i] == id) {
            bookIndex = i;
            break;
        }
    }
    availableCopies[bookIndex]++;

    for (i = borrowedIndex; i < *borrowedCount - 1; i++)
        borrowedBookIDs[i] = borrowedBookIDs[i + 1];
    (*borrowedCount)--;

    if (days > allowed) {
        fine = (float)(days - allowed) * rate;
        payable = fine;
        printf("Book returned %d day(s) late. Fine: Rs. %.2f\n", days - allowed, fine);

        printf("Enter membership code for fine waiver (or any text to skip): ");
        scanf(" %49s", code);
        if (strcmp(code, WAIVER_CODE) == 0) {
            payable = fine * 0.5f;
            printf("Correct code. 50%% waiver applied. Fine payable: Rs. %.2f\n", payable);
        } else {
            printf("Incorrect code. No waiver applied. Fine payable: Rs. %.2f\n", payable);
        }
    } else {
        printf("Book returned on time. No fine.\n");
    }

    *totalFine=*totalFine+ fine;
    return payable;
}

void displayMemberRecord(char name[], int studentID, int memberType, int borrowedBookIDs[],
                         int borrowedCount, float totalFine, float fineAfterWaiver)
{
    int i;
    printf("\n----- Member Record -----\n");
    printf("Name            : %s\n", name);
    printf("Student ID      : %d\n", studentID);
    printf("Membership Type : %s\n", (memberType == STUDENT) ? "Student" : "Faculty");
    printf("Borrowed Books  : ");
    if (borrowedCount == 0)
        printf("None");
    for (i = 0; i < borrowedCount; i++)
        printf("%d%s", borrowedBookIDs[i], (i < borrowedCount - 1) ? ", " : "");
    printf("\nTotal fine before waiver : Rs. %.2f\n", totalFine);
    printf("Final fine payable     : Rs. %.2f\n", fineAfterWaiver);
}

int main()
{
    int bookIDs[4] = {101, 102, 103, 104};
    char bookTitles[4][50] = {"Programming in C", "Data Structures", "Database Systems", "Computer Networks"};
    int availableCopies[4] = {5, 3, 0, 4};
    int totalBooks = 4;

    char name[50] = "";
    int studentID = 0, memberType = 0;
    int borrowedBookIDs[MAX_BORROW];
    int borrowedCount = 0;
    float totalFine = 0.0f, fineAfterWaiver = 0.0f;
    int registered = 0;
    int choice;

    do {
        displayMenu();
        choice = readInt();

        if (choice >= 3 && choice <= 5 && !registered) {
            printf("Please register as a member first (option 1).\n");
            continue;
        }

        switch (choice) {
        case 1:
            if (registered)
                printf("A member is already registered.\n");
            else {
                registerMember(name, &studentID, &memberType);
                registered = 1;
            }
            break;
        case 2:
            displayBooks(bookIDs, bookTitles, availableCopies, totalBooks);
            break;
        case 3:
            borrowBook(bookIDs, bookTitles, availableCopies, totalBooks,borrowedBookIDs, &borrowedCount, memberType);
            break;
        case 4:
            fineAfterWaiver += returnBook(bookIDs, availableCopies, totalBooks,borrowedBookIDs, &borrowedCount, memberType, &totalFine);
            break;
        case 5:
            displayMemberRecord(name, studentID, memberType, borrowedBookIDs,
                                borrowedCount, totalFine, fineAfterWaiver);
            break;
        case 6:
            printf("Thank you for using the library system. Goodbye!\n");
            break;
        default:
            printf("Invalid choice. Please select 1-6.\n");
        }
    } 
    while (choice != 6);
    return 0;
}
