#include<stdio.h>

    int sum_proper_divisor(int num);
    int main(){
    int sum=0;
    int i,n,sum1,sum2;

    printf("Enter number n:");
    scanf("%d",&n);

    printf("pairs up to %d\n",n);
    for(i=1;i<=n/2;i++){
        sum1=sum_proper_divisor(i);
        if(sum1>n||sum1==i){
            continue;
        }
        sum2=sum_proper_divisor(sum1);
        if(sum2==i&&i<sum1){
            printf("%d,%d\n",i,sum1);
            sum++;
        }
    }
    if(sum>0){
        printf("Total pairs: %d\n",sum);
    }
    else{
        printf("No pair is found upto %d\n",n);
    }
    return 0;
}
int sum_proper_divisor(int num){
    int sum=0;
    int i;
    for(i=1;i<=num/2;i++){
        if(num%i==0){
            sum=sum+i;
        }
    }
   return sum;
}