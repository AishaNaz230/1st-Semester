#include<stdio.h>

void input_readings(int temp[][50],int sensors,int readings);
float analyze_sensor(int temp[],int readings,int sensor_num);
int highest_average(float avg[],int sensors);

int main(){
    int sensors,num_readings;
    int temp[50][50];
    float avg[50];
    int highest_sensor;

    printf("Enter number of sensors : ");
    scanf("%d",&sensors);
    printf("Enter number of readings : ");
    scanf("%d",&num_readings);

    input_readings(temp,sensors,num_readings);

    for(int i=0;i<sensors;i++){
        avg[i]=analyze_sensor(temp[i],num_readings,i+1);
    }

    highest_sensor=highest_average(avg,sensors);
    printf("Highest average:Sensor %d(%.2f)\n",highest_sensor+1,avg[highest_sensor]);
    return 0;
}

void input_readings(int temp[][50],int sensors,int readings){
    for(int i=0;i<sensors;i++){
        printf("Sensors %d: ",i+1);
        for(int j=0;j<readings;j++){
           scanf("%d",&temp[i][j]);
        }
    }
}
float analyze_sensor(int temp[],int readings,int sensor_num){
    int total=0;
    int max=temp[0];
    int min=temp[0];
    int criticle=0;
    int warning=0;
    int long_streak=0;
    int current_streak=0;

    for(int j=0;j<readings;j++){
        total=total+temp[j];

        if(temp[j]>max){
            max=temp[j];
        }
        if(temp[j]<min){
            min=temp[j];
        }
        if(temp[j]>=40){
            criticle++;
        }
        if(temp[j]>=35 && temp[j]<=39){
            warning++;
        }
        if(temp[j]>=35){
            current_streak++;
              if(current_streak>long_streak){
            long_streak=current_streak;
        }
    }
    else{
        current_streak=0;
    }
    }
    float avg=(float)total/readings;
    printf("Sensor %d: Total=%d Average=%.2f Max=%d Min=%d\n",sensor_num,total,avg,max,min);
    printf("       Criticle=%d  warning=%d  longest hot streak=%d\n",criticle,warning,long_streak);
    return avg;
}

int highest_average(float avg[],int sensors){
    int highest_index=0;
    float highest=avg[0];
    for(int i=1;i<sensors;i++){
        if(avg[i]>highest){
            highest=avg[i];
            highest_index=i;
        }
    }
    return highest_index;
}
